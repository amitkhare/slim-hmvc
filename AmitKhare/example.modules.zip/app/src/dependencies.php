<?php
// DIC configuration

$container = $app->getContainer();
