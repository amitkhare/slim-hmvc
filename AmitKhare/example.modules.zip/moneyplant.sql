-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: May 05, 2016 at 09:41 PM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `inkimagi_moneyplant`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url_name` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `url_name`, `description`, `created_at`, `updated_at`, `visible`) VALUES
(1, 'Personal', 'personal', 'This category should be use for self expenses', '2016-04-15 16:53:38', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `description`, `price`, `visible`, `created_at`, `updated_at`) VALUES
(1, '', 545.54, 1, '2016-04-15 16:40:18', '0000-00-00 00:00:00'),
(2, '', 458.51, 1, '2016-04-15 16:48:23', '0000-00-00 00:00:00'),
(3, 'Samosa', 112.12, 1, '2016-04-24 16:25:46', '0000-00-00 00:00:00'),
(4, 'Samosa', 112.12, 1, '2016-04-24 16:46:24', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL DEFAULT 'Default',
  `url_name` varchar(250) NOT NULL DEFAULT 'default',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `url_name`, `created_at`, `updated_at`, `visible`) VALUES
(1, 'Roomies', 'roomies', '2016-04-15 17:54:54', '0000-00-00 00:00:00', 1),
(2, 'Office', 'Office', '2016-04-15 17:54:54', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rel_expenses_categories`
--

CREATE TABLE `rel_expenses_categories` (
  `id` int(11) NOT NULL,
  `expense_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rel_expenses_categories`
--

INSERT INTO `rel_expenses_categories` (`id`, `expense_id`, `category_id`, `created_at`, `updated_at`, `visible`) VALUES
(1, 1, 1, '2016-04-15 17:36:54', '0000-00-00 00:00:00', 1),
(2, 1, 1, '2016-04-15 17:36:54', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rel_expenses_groups`
--

CREATE TABLE `rel_expenses_groups` (
  `id` int(11) NOT NULL,
  `expense_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rel_expenses_groups`
--

INSERT INTO `rel_expenses_groups` (`id`, `expense_id`, `group_id`, `created_at`, `updated_at`, `visible`) VALUES
(1, 1, 1, '2016-04-15 17:36:54', '0000-00-00 00:00:00', 1),
(2, 2, 2, '2016-04-15 17:36:54', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rel_expenses_tags`
--

CREATE TABLE `rel_expenses_tags` (
  `id` int(11) NOT NULL,
  `expense_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rel_expenses_tags`
--

INSERT INTO `rel_expenses_tags` (`id`, `expense_id`, `tag_id`, `created_at`, `updated_at`, `visible`) VALUES
(1, 1, 1, '2016-04-15 16:42:04', '0000-00-00 00:00:00', 1),
(2, 1, 2, '2016-04-15 16:42:04', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rel_users_categories`
--

CREATE TABLE `rel_users_categories` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rel_users_expenses`
--

CREATE TABLE `rel_users_expenses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `expense_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rel_users_expenses`
--

INSERT INTO `rel_users_expenses` (`id`, `user_id`, `expense_id`, `created_at`, `updated_at`, `visible`) VALUES
(1, 1, 1, '2016-04-15 16:37:00', '0000-00-00 00:00:00', 1),
(2, 1, 2, '2016-04-15 16:37:00', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rel_users_tags`
--

CREATE TABLE `rel_users_tags` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rel_users_tags`
--

INSERT INTO `rel_users_tags` (`id`, `user_id`, `tag_id`, `created_at`, `updated_at`, `visible`) VALUES
(1, 1, 1, '2016-04-15 16:37:25', '0000-00-00 00:00:00', 1),
(2, 1, 2, '2016-04-15 16:37:25', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `url_name` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `url_name`, `created_at`, `updated_at`, `visible`) VALUES
(1, 'n1', '', '2016-04-15 15:07:20', '0000-00-00 00:00:00', 1),
(2, 'n2', '', '2016-04-15 16:27:04', '0000-00-00 00:00:00', 1),
(3, 'n3', '', '2016-04-15 16:27:04', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(70) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `created_at`, `updated_at`, `visible`) VALUES
(1, 'testuserna', 'pword', 'med@mail.com', '2016-04-15 16:10:51', '0000-00-00 00:00:00', 0),
(7, 'tests', 'd41d8cd98f00b204e9800998ecf8427e', 'me@mail.com', '2016-05-05 16:06:03', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `_basicTable`
--

CREATE TABLE `_basicTable` (
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rel_expenses_categories`
--
ALTER TABLE `rel_expenses_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rel_expenses_groups`
--
ALTER TABLE `rel_expenses_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rel_expenses_tags`
--
ALTER TABLE `rel_expenses_tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rel_users_categories`
--
ALTER TABLE `rel_users_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rel_users_expenses`
--
ALTER TABLE `rel_users_expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rel_users_tags`
--
ALTER TABLE `rel_users_tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`email`);

--
-- Indexes for table `_basicTable`
--
ALTER TABLE `_basicTable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `rel_expenses_categories`
--
ALTER TABLE `rel_expenses_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `rel_expenses_groups`
--
ALTER TABLE `rel_expenses_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `rel_expenses_tags`
--
ALTER TABLE `rel_expenses_tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `rel_users_categories`
--
ALTER TABLE `rel_users_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rel_users_expenses`
--
ALTER TABLE `rel_users_expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `rel_users_tags`
--
ALTER TABLE `rel_users_tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `_basicTable`
--
ALTER TABLE `_basicTable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;